from utils.game import Hangman

if __name__ == '__main__':
    hangman = Hangman()
    hangman.start_game()

# desolé j'ai oublié le readme